ORM with basic functions like INSERT, UPDATE, etc.


